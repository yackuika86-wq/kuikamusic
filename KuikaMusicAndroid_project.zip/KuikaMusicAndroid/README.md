# KuikaMusic para Android

Proyecto Android Studio (Kotlin + WebView) que empaqueta `kuikamusic.html` como aplicación Android y permite seleccionar archivos de audio del dispositivo.

## Crear el APK

1. Instala Android Studio en una computadora.
2. Abre esta carpeta (`KuikaMusicAndroid`) desde Android Studio.
3. Acepta instalar Android SDK Platform 35 y espera a que Gradle sincronice.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/`.

Para distribuirla públicamente, crea una versión firmada desde **Build > Generate Signed Bundle / APK** y revisa las políticas y permisos aplicables.

## Notas

- Nombre de la aplicación: KuikaMusic.
- Identificador: `com.kuikamusic.app`.
- El reproductor HTML se encuentra en `app/src/main/assets/kuikamusic.html`.
- Requiere conexión para consultar el catálogo remoto; los archivos locales se reproducen desde el dispositivo.
- Este paquete es el proyecto fuente. No contiene un APK compilado ni firmado.
